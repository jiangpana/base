#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}
import com.jansir.core.base.activity.BaseVMActivity
#end
#parse("File Header.java")

class ${NAME} : BaseVMActivity<$binding , ${viewmodel}ViewModel>() {


    override fun initListener() {

    }

    override fun initView() {

    }

    override fun initData() {
    }


}