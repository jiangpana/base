#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}
import android.content.Context
import android.util.AttributeSet
import ${PACKAGE_NAME}.R#end
#parse("File Header.java")



class ${NAME} @JvmOverloads constructor(context: Context, attributeSet: AttributeSet? = null, defStyleAttr: Int = 0)
    : xxx (context, attributeSet, defStyleAttr) {

   
    init {
        val ta = context.obtainStyledAttributes(attributeSet, R.styleable.${NAME})
      
        ta.recycle()
    }

}