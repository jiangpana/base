#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}
import com.jansir.core.base.viewmodel.BaseViewModel
#end
#parse("File Header.java")


class $NAME : BaseViewModel() {


}